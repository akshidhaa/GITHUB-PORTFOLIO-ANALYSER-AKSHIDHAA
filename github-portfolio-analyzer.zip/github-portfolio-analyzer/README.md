# GitHub Portfolio Analyzer & Enhancer 🚀

An AI-powered evaluation tool for GitHub profiles designed to help developers signal their impact to recruiters.

## Features
- **Portfolio Scoring**: Calculates a strength score (0-100) based on repository metrics.
- **AI Insights**: Generates actionable advice for profile bio and repo documentation.
- **Tech Density**: Visualizes your coding language distribution.
- **Premium UI**: Glassmorphic dark-theme design with neon accents and fluid animations.

## How to Run

Follow these steps to get the application running on your local machine:

### 1. Open the project directory
Open your terminal and navigate to the project folder:
```bash
cd github-portfolio-analyzer
```

### 2. Install Dependencies
Ensure all necessary packages are installed:
```bash
npm install
```

### 3. Start the Development Server
Run the application in development mode:
```bash
npm run dev
```

### 4. View in Browser
Once the server starts, it will provide a local URL (usually `http://localhost:5173`). Open this link in your browser to start analyzing profiles!

## Tech Stack
- **Frontend**: React.js + Vite
- **Styling**: Vanilla CSS (Premium Custom Theme)
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **Data Integration**: GitHub REST API + Axios
