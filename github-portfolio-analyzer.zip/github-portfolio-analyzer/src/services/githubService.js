import axios from 'axios';

const GITHUB_API_BASE = 'https://api.github.com';

export const fetchGitHubData = async (username) => {
    try {
        // Note: In a real app, we'd use an auth token to avoid rate limiting
        const [profile, repos, activities] = await Promise.all([
            axios.get(`${GITHUB_API_BASE}/users/${username}`),
            axios.get(`${GITHUB_API_BASE}/users/${username}/repos?sort=updated&per_page=100`),
            axios.get(`${GITHUB_API_BASE}/users/${username}/events/public`)
        ]);

        return {
            profile: profile.data,
            repos: repos.data,
            activities: activities.data
        };
    } catch (error) {
        console.error('Error fetching data from GitHub:', error);
        throw error;
    }
};

export const analyzePortfolio = (data) => {
    const { profile, repos, activities } = data;

    // 1. Language & Tech Density
    const languages = {};
    let totalStars = 0;
    let polishedRepos = 0; // Repos with topics or homepage links (Signals expertise)

    repos.forEach(repo => {
        if (repo.language) {
            languages[repo.language] = (languages[repo.language] || 0) + 1;
        }
        totalStars += repo.stargazers_count;

        // Polished marker: Has a description AND (topics OR homepage OR wiki OR pages)
        if (repo.description && (repo.topics?.length > 0 || repo.homepage || repo.has_pages)) {
            polishedRepos++;
        }
    });

    // 2. Metrics Calculation
    const repoCount = repos.length;
    const avgStars = totalStars / repoCount || 0;
    const forksCount = repos.reduce((acc, repo) => acc + repo.forks_count, 0);
    const hasDescriptionRate = (repos.filter(r => r.description).length / repoCount) * 100 || 0;
    const hasLicenseRate = (repos.filter(r => r.license).length / repoCount) * 100 || 0;

    // 3. Activity Calculation (Based on actual public events)
    const recentEvents = activities.length;
    const pushEvents = activities.filter(e => e.type === 'PushEvent').length;
    const activitySignal = Math.min(100, Math.round((pushEvents / 10) * 60 + (recentEvents / 30) * 40));

    // 4. Sub-Scores (0-100)

    // Documentation Score: Descriptions, Licenses, Bio, and Polished Repos
    const docScore = Math.round(
        (hasDescriptionRate * 0.3) +
        (hasLicenseRate * 0.2) +
        ((polishedRepos / Math.max(1, repoCount)) * 300) + // Significant boost for polished work
        (profile.bio ? 20 : 0)
    );

    // Activity Score: Reified signal from events
    const activityScore = activitySignal;

    // Technical Depth: Stars, Forks, Language diversity, and polished count
    const langCount = Object.keys(languages).length;
    const depthScore = Math.min(100, Math.round(
        (Math.min(avgStars * 15, 30)) +
        (Math.min(langCount * 8, 20)) +
        (Math.min(polishedRepos * 15, 30)) +
        (Math.min(totalStars, 20))
    ));

    // 5. Total Portfolio Score (Recruiter Readiness)
    const totalScore = Math.min(100, Math.round((docScore * 0.25) + (activityScore * 0.35) + (depthScore * 0.4)));

    // 6. Recruiter Insights
    const insights = [];

    // Red Flags
    if (docScore < 30) {
        insights.push({
            type: 'critical',
            title: 'Documentation Void',
            message: 'A recruiter cannot understand your impact without descriptions. Most of your repos are "quiet".',
            action: 'Add meaningful READMEs and MIT/Apache licenses to your top projects.'
        });
    }

    if (activityScore < 25) {
        insights.push({
            type: 'warning',
            title: 'Stagnant Activity',
            message: 'Your public timeline shows minimal code movement. Recruiters favor consistent builders.',
            action: 'Commit regularly or contribute to open-source to show active development.'
        });
    }

    if (!profile.bio || profile.bio.length < 15) {
        insights.push({
            type: 'critical',
            title: 'Identity Crisis',
            message: 'Your profile bio is the first thing a recruiter sees. It is currently underutilized.',
            action: 'Update your GitHub bio with your primary tech stack (e.g., "Fullstack React Developer").'
        });
    }

    // Strong Signals
    if (polishedRepos > 3) {
        insights.push({
            type: 'tip',
            title: 'Professional Signal: Strong',
            message: `You have ${polishedRepos} repositories with high discovery markers (topics/homepages).`,
            action: 'Ensure these repos are pinned and their READMEs have screenshots.'
        });
    }

    if (depthScore > 65) {
        insights.push({
            type: 'tip',
            title: 'Architectural Depth',
            message: 'Your profile shows multi-language proficiency and community interaction.',
            action: 'Highlight your best architectural decision in your top repo README.'
        });
    }

    if (totalStars > 5) {
        insights.push({
            type: 'tip',
            title: 'Community Trusted',
            message: `Your work has gained community interest with ${totalStars} total stars.`,
            action: 'Pin your most-starred repositories to your profile top.'
        });
    }

    return {
        score: totalScore,
        subScores: {
            documentation: Math.min(100, docScore),
            activity: Math.min(100, activityScore),
            technicalDepth: Math.min(100, depthScore)
        },
        languages,
        metrics: {
            stars: avgStars.toFixed(1),
            totalStars,
            forks: forksCount,
            repoCount,
            polishedRepos,
            followers: profile.followers
        },
        insights
    };
};
