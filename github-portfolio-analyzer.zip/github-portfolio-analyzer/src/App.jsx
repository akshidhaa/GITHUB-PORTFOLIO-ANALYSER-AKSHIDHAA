import React, { useState } from 'react';
import {
  Search,
  Github,
  Star,
  GitFork,
  BookOpen,
  Users,
  AlertCircle,
  Zap,
  CheckCircle,
  TrendingUp,
  Code,
  FileText,
  Activity,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { fetchGitHubData, analyzePortfolio } from './services/githubService';

// --- Components ---

function StatCard({ icon, label, value, subLabel }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="glass-card p-6 flex flex-col gap-2"
    >
      <div className="flex items-center gap-3 text-cyan-400">
        <div className="p-2 bg-cyan-500/10 rounded-lg">{icon}</div>
        <span className="text-sm font-semibold tracking-wider text-slate-400">{label.toUpperCase()}</span>
      </div>
      <div className="text-3xl font-bold mt-2">{value}</div>
      {subLabel && <div className="text-xs text-slate-500">{subLabel}</div>}
    </motion.div>
  );
}

function SubScoreCard({ label, score, icon, color }) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-between items-center text-sm font-semibold">
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-slate-300">{label}</span>
        </div>
        <span className="text-white">{score}%</span>
      </div>
      <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
    </div>
  );
}

function InsightCard({ insight }) {
  const isCritical = insight.type === 'critical';
  const isWarning = insight.type === 'warning';

  const Icon = isCritical ? AlertCircle : (isWarning ? Zap : CheckCircle);
  const borderColor = isCritical ? 'rgba(255, 77, 77, 0.4)' : (isWarning ? 'rgba(255, 170, 0, 0.4)' : 'rgba(0, 242, 255, 0.4)');
  const bgColor = isCritical ? 'rgba(255, 77, 77, 0.05)' : (isWarning ? 'rgba(255, 170, 0, 0.05)' : 'rgba(0, 242, 255, 0.05)');

  return (
    <motion.div
      whileHover={{ x: 5 }}
      className="glass-card p-6 border-l-4 overflow-hidden relative"
      style={{ borderLeftColor: borderColor, background: bgColor }}
    >
      <div className="flex items-start gap-4">
        <div className={isCritical ? 'text-red-400' : (isWarning ? 'text-yellow-400' : 'text-cyan-400')}>
          <Icon size={24} />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-lg mb-1">{insight.title}</h4>
          <p className="text-sm text-slate-400 leading-relaxed mb-4">{insight.message}</p>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 bg-cyan-400/10 w-fit px-3 py-1.5 rounded-full">
            <ArrowRight size={14} />
            FIX: {insight.action}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// --- Main Pages ---

function Landing({ onAnalyze, loading, error }) {
  const [input, setInput] = useState('');

  return (
    <div className="max-w-4xl mx-auto pt-24 px-6 text-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/10 mb-8">
          <TrendingUp size={16} className="text-cyan-400" />
          <span className="text-xs font-bold tracking-widest text-slate-400">AI-POWERED RECRUITER ANALYTICS</span>
        </div>
        <h1 className="text-6xl md:text-7xl font-extrabold mb-8 leading-tight">
          Decode Your <br />
          <span className="neon-text">GitHub Signal</span>.
        </h1>
        <p className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto leading-relaxed">
          Stop wondering how recruiters see your profile. Our AI engine evaluates your documentation, activity consistency, and technical depth.
        </p>

        <form
          onSubmit={(e) => { e.preventDefault(); onAnalyze(input); }}
          className="relative max-w-xl mx-auto flex flex-col md:flex-row gap-4"
        >
          <div className="relative flex-1">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
            <input
              type="text"
              placeholder="github.com/username"
              className="input-field pl-16 pr-6 w-full"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
          </div>
          <button disabled={loading} className="neon-btn h-[60px] whitespace-nowrap">
            {loading ? <RefreshCw className="animate-spin inline mr-2" /> : 'ANALYZE NOW'}
          </button>
        </form>
        {error && <p className="mt-6 text-red-400 font-semibold">{error}</p>}

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 opacity-40 grayscale group hover:opacity-100 hover:grayscale-0 transition-all duration-700">
          {/* Decorative tech logos or stats could go here */}
        </div>
      </motion.div>
    </div>
  );
}

function Dashboard({ data, onReset }) {
  const { profile, analysis } = data;

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12"
      >
        <div className="flex items-center gap-6">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full blur opacity-40 group-hover:opacity-100 transition duration-1000"></div>
            <img src={profile.avatar_url} className="relative w-24 h-24 rounded-full border-2 border-white/20" alt="" />
          </div>
          <div>
            <h2 className="text-3xl font-bold">{profile.name || profile.login}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-cyan-400 font-bold">@{profile.login}</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 text-sm">{profile.location || 'Remote'}</span>
            </div>
            <p className="text-slate-400 mt-2 max-w-md line-clamp-2 text-sm">{profile.bio || "No professional summary provided."}</p>
          </div>
        </div>

        <div className="flex items-center gap-6 w-full md:w-auto">
          <div className="glass-card flex items-center gap-6 px-10 py-5">
            <div className="text-center">
              <div className="text-5xl font-black neon-text leading-none">{analysis.score}</div>
              <div className="text-[10px] font-bold tracking-[0.2em] text-slate-500 mt-2 uppercase">Global Score</div>
            </div>
            <div className="h-12 w-[1px] bg-white/10"></div>
            <div className="text-slate-400 text-sm font-medium leading-relaxed">
              Your profile is <br />
              <span className="text-white font-bold">{analysis.score > 80 ? 'Elite' : analysis.score > 60 ? 'Strong' : 'Basic'} Quality</span>
            </div>
          </div>
          <button onClick={onReset} className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl transition-all border border-white/10">
            <RefreshCw size={20} className="text-slate-400" />
          </button>
        </div>
      </motion.header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column - Stats & Analysis */}
        <div className="lg:col-span-8 flex flex-col gap-8">

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <SubScoreCard
              label="Documentation"
              score={analysis.subScores.documentation}
              icon={<FileText size={16} className="text-purple-400" />}
              color="linear-gradient(90deg, #7000ff, #bc13fe)"
            />
            <SubScoreCard
              label="Activity Signals"
              score={analysis.subScores.activity}
              icon={<Activity size={16} className="text-cyan-400" />}
              color="linear-gradient(90deg, #00f2ff, #7000ff)"
            />
            <SubScoreCard
              label="Technical Depth"
              score={analysis.subScores.technicalDepth}
              icon={<Code size={16} className="text-pink-400" />}
              color="linear-gradient(90deg, #ff00c1, #00f2ff)"
            />
          </div>

          <section>
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Zap size={20} className="text-cyan-400" />
              RECRUITER <span className="neon-text">INSIGHTS</span>
            </h3>
            <div className="flex flex-col gap-4">
              {analysis.insights.map((insight, idx) => (
                <InsightCard key={idx} insight={insight} />
              ))}
            </div>
          </section>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <StatCard icon={<Star size={18} />} label="Quality" value={analysis.metrics.stars} subLabel="Avg Stars/Repo" />
            <StatCard icon={<GitFork size={18} />} label="Reach" value={analysis.metrics.forks} subLabel="Total Forks" />
            <StatCard icon={<BookOpen size={18} />} label="Scope" value={analysis.metrics.repoCount} subLabel="Public Assets" />
            <StatCard icon={<Users size={18} />} label="Network" value={analysis.metrics.followers} subLabel="Followers" />
            <StatCard icon={<CheckCircle size={18} />} label="Polished" value={analysis.metrics.polishedRepos} subLabel="Discovery Ready" />
          </div>
        </div>

        {/* Right Column - Tech Stack */}
        <div className="lg:col-span-4 flex flex-col gap-8">
          <section className="glass-card p-8 h-full">
            <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
              <Code size={20} className="text-purple-400" />
              TECH <span className="neon-text">DENSITY</span>
            </h3>
            <div className="flex flex-col gap-6">
              {Object.entries(analysis.languages)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 8)
                .map(([lang, count]) => (
                  <div key={lang} className="group">
                    <div className="flex justify-between text-sm mb-2 px-1">
                      <span className="font-bold text-slate-300 group-hover:text-cyan-400 transition-colors uppercase tracking-tight">{lang}</span>
                      <span className="text-slate-500 font-mono">{count} repos</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(count / analysis.metrics.repoCount) * 100}%` }}
                        className="h-full bg-gradient-to-r from-cyan-400 to-purple-600 rounded-full"
                      />
                    </div>
                  </div>
                ))}
            </div>

            <div className="mt-12 p-6 bg-cyan-400/5 rounded-2xl border border-cyan-400/10">
              <h4 className="text-xs font-bold text-cyan-400 tracking-widest mb-2 uppercase">Hiring Tip</h4>
              <p className="text-xs text-slate-400 leading-relaxed italic">
                Recruiters look for language consistency. A deep focus in 1-2 languages often signals expertise better than wide but shallow knowledge.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const handleAnalyze = async (rawUsername) => {
    // Basic URL cleaning
    const username = rawUsername.split('/').pop().trim();
    if (!username) return;

    setLoading(true);
    setError('');
    try {
      const rawData = await fetchGitHubData(username);
      const analysis = analyzePortfolio(rawData);
      setData({ ...rawData, analysis });
    } catch (err) {
      setError('Profile unavailable. Check the username or retry later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden pb-20">
      {/* Dynamic Background Elements */}
      <div className="fixed top-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[120px] rounded-full -z-10 animate-pulse"></div>
      <div className="fixed bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-cyan-600/10 blur-[120px] rounded-full -z-10 animate-pulse" style={{ animationDelay: '1s' }}></div>

      <nav className="h-24 px-8 flex items-center justify-between border-b border-white/5 sticky top-0 bg-black/50 backdrop-blur-xl z-50">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setData(null)}>
          <div className="w-10 h-10 bg-cyan-400 rounded-xl flex items-center justify-center">
            <Github size={24} className="text-black" />
          </div>
          <span className="text-lg font-black tracking-tighter">
            SIGNAL.<span className="neon-text">AI</span>
          </span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-xs font-bold tracking-widest text-slate-400">
          <a href="#" className="hover:text-white transition-colors">METHODOLOGY</a>
          <a href="#" className="hover:text-white transition-colors">API v1.0</a>
          <div className="px-3 py-1 bg-green-400/10 text-green-400 rounded-full border border-green-400/20 flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
            SYSTEM OPERATIONAL
          </div>
        </div>
      </nav>

      <main>
        <AnimatePresence mode="wait">
          {!data ? (
            <Landing key="landing" onAnalyze={handleAnalyze} loading={loading} error={error} />
          ) : (
            <Dashboard key="dashboard" data={data} onReset={() => setData(null)} />
          )}
        </AnimatePresence>
      </main>

      <footer className="mt-20 text-center text-slate-600 text-[10px] tracking-[0.3em] font-bold uppercase">
        © 2026 SIGNAL ANALYTICS CORE • BUILT FOR BUILDERS
      </footer>

      {/* Tailwind and other utility styles injected for quick prototyping without adding full Tailwind config */}
      <style dangerouslySetInnerHTML={{
        __html: `
        .flex { display: flex; }
        .flex-col { flex-direction: column; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-2 { gap: 0.5rem; }
        .gap-3 { gap: 0.75rem; }
        .gap-4 { gap: 1rem; }
        .gap-6 { gap: 1.5rem; }
        .gap-8 { gap: 2rem; }
        .gap-12 { gap: 3rem; }
        .p-2 { padding: 0.5rem; }
        .p-4 { padding: 1rem; }
        .p-6 { padding: 1.5rem; }
        .p-8 { padding: 2rem; }
        .px-1 { padding-left: 0.25rem; padding-right: 0.25rem; }
        .px-3 { padding-left: 0.75rem; padding-right: 0.75rem; }
        .px-4 { padding-left: 1rem; padding-right: 1rem; }
        .py-1 { padding-top: 0.25rem; padding-bottom: 0.25rem; }
        .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
        .py-5 { padding-top: 1.25rem; padding-bottom: 1.25rem; }
        .pt-24 { padding-top: 6rem; }
        .mt-1 { margin-top: 0.25rem; }
        .mt-2 { margin-top: 0.5rem; }
        .mt-6 { margin-top: 1.5rem; }
        .mt-8 { margin-top: 2rem; }
        .mt-12 { margin-top: 3rem; }
        .mt-20 { margin-top: 5rem; }
        .mb-1 { margin-bottom: 0.25rem; }
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-4 { margin-bottom: 1rem; }
        .mb-6 { margin-bottom: 1.5rem; }
        .mb-8 { margin-bottom: 2rem; }
        .mb-12 { margin-bottom: 3rem; }
        .text-xs { font-size: 0.75rem; }
        .text-sm { font-size: 0.875rem; }
        .text-lg { font-size: 1.125rem; }
        .text-xl { font-size: 1.25rem; }
        .text-3xl { font-size: 1.875rem; }
        .text-5xl { font-size: 3rem; }
        .text-6xl { font-size: 3.75rem; }
        .text-7xl { font-size: 4.5rem; }
        .font-bold { font-weight: 700; }
        .font-semibold { font-weight: 600; }
        .font-extrabold { font-weight: 800; }
        .font-black { font-weight: 900; }
        .tracking-wider { letter-spacing: 0.05em; }
        .tracking-widest { letter-spacing: 0.1em; }
        .tracking-tight { letter-spacing: -0.025em; }
        .tracking-tighter { letter-spacing: -0.05em; }
        .uppercase { text-transform: uppercase; }
        .text-center { text-align: center; }
        .max-w-xl { max-width: 36rem; }
        .max-w-2xl { max-width: 42rem; }
        .max-w-4xl { max-width: 56rem; }
        .max-w-7xl { max-width: 80rem; }
        .mx-auto { margin-left: auto; margin-right: auto; }
        .w-full { width: 100%; }
        .w-10 { width: 2.5rem; }
        .w-24 { width: 6rem; }
        .h-2 { height: 0.5rem; }
        .h-10 { height: 2.5rem; }
        .h-12 { height: 3rem; }
        .h-24 { height: 6rem; }
        .h-[60px] { height: 60px; }
        .h-full { height: 100%; }
        .rounded-xl { border-radius: 0.75rem; }
        .rounded-2xl { border-radius: 1rem; }
        .rounded-full { border-radius: 9999px; }
        .border { border-width: 1px; }
        .border-b { border-bottom-width: 1px; }
        .border-l-4 { border-left-width: 4px; }
        .border-white\/5 { border-color: rgba(255, 255, 255, 0.05); }
        .border-white\/10 { border-color: rgba(255, 255, 255, 0.1); }
        .border-white\/20 { border-color: rgba(255, 255, 255, 0.2); }
        .bg-black\/50 { background-color: rgba(0, 0, 0, 0.5); }
        .bg-white\/5 { background-color: rgba(255, 255, 255, 0.05); }
        .bg-white\/10 { background-color: rgba(255, 255, 255, 0.1); }
        .bg-cyan-400\/10 { background-color: rgba(0, 242, 255, 0.1); }
        .bg-cyan-400\/5 { background-color: rgba(0, 242, 255, 0.05); }
        .text-white { color: white; }
        .text-black { color: black; }
        .text-cyan-400 { color: #00f2ff; }
        .text-slate-300 { color: #cbd5e1; }
        .text-slate-400 { color: #94a3b8; }
        .text-slate-500 { color: #64748b; }
        .text-slate-600 { color: #475569; }
        .text-red-400 { color: #f87171; }
        .animate-spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .grid { display: grid; }
        .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
        @media (min-width: 768px) {
          .md\\:flex { display: flex; }
          .md\\:flex-row { flex-direction: row; }
          .md\\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
          .md\\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
          .md\\:w-auto { width: auto; }
          .md\\:items-center { align-items: center; }
        }
        @media (min-width: 1024px) {
          .lg\\:grid-cols-12 { grid-template-columns: repeat(12, minmax(0, 1fr)); }
          .lg\\:col-span-8 { grid-column: span 8 / span 8; }
          .lg\\:col-span-4 { grid-column: span 4 / span 4; }
        }
        .backdrop-blur-xl { backdrop-filter: blur(24px); }
        .sticky { position: sticky; }
        .top-0 { top: 0; }
        .z-50 { z-index: 50; }
        .overflow-hidden { overflow: hidden; }
        .relative { position: relative; }
        .absolute { position: absolute; }
        .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
        .blur { filter: blur(8px); }
        .opacity-40 { opacity: 0.4; }
        .group:hover .group-hover\\:opacity-100 { opacity: 1; }
      `}} />
    </div>
  );
}

export default App;
